import sys
name=input('Enter your name')
print('Hello',name)
print('Hello',sys.argv[1])

